-- This file should undo anything in `up.sql`
DROP TABLE public.peer;
DROP TABLE public.interface;
DROP TABLE public.vpnUser;

